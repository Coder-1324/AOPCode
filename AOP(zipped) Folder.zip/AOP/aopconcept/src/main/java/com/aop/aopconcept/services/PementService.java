package com.aop.aopconcept.services;

public interface PementService {

	public void makePeyment();
}
