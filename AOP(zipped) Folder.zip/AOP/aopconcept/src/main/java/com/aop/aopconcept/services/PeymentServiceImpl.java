package com.aop.aopconcept.services;

public class PeymentServiceImpl  implements PementService{

	public void makePeyment() {
		
		System.out.println("amount debited.......");
		
		System.out.println("Amount credited............");
		
		
	}
}
